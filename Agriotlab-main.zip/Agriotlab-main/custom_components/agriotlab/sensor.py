{
  "domain": "agriotlab",
  "name": "AgriotLab",
  "version": "0.1.0",
  "config_flow": true,
  "integration_type": "hub",
  "requirements": [],
  "codeowners": ["@hypertheasis"],
  "iot_class": "cloud_polling"
}
