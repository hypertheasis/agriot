DOMAIN = "agriotlab"

PLATFORMS = ["sensor"]

CONF_LOCATION_NAME = "location_name"
CONF_LATITUDE = "latitude"
CONF_LONGITUDE = "longitude"
